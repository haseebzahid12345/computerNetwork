from tkinter import *
import socket
from tkinter import filedialog
import os
import threading

# Initialize the main window
root = Tk()
root.title("Shareit")
root.geometry("450x560+500+200")
root.configure(bg="#f4fdfe")
root.resizable(False, False)

filename = ""  # Global variable for the selected file


def Send():
    window = Toplevel(root)
    window.title("Send")
    window.geometry('450x560+500+200')
    window.configure(bg="#f4fdfe")
    window.resizable(False, False)

    def select_file():
        global filename
        filename = filedialog.askopenfilename(
            initialdir=os.getcwd(),
            title='Select File',
            filetype=(('Text files', '*.txt'), ('All files', '*.*'))
        )
        if filename:
            print(f"Selected file: {os.path.basename(filename)}")
        else:
            print("No file selected")

    def sender():
        if not filename:
            print("No file selected to send!")
            return

        def send_file():
            try:
                print(f"Sending file: {filename}")
                s = socket.socket()
                host = socket.gethostname()
                port = 8080
                s.bind((host, port))
                s.listen(1)
                conn, addr = s.accept()
                print(f"Connected to {addr}. Sending file...")

                # Send the filename first
                filename_to_send = os.path.basename(filename)
                conn.send(filename_to_send.encode())

                # Now send the file data
                with open(filename, 'rb') as file:
                    while (data := file.read(1024)):
                        conn.send(data)

                print(f"{filename_to_send} sent successfully!")
                conn.close()
                s.close()
            except Exception as e:
                print(f"Error: {str(e)}")

        threading.Thread(target=send_file, daemon=True).start()

    # UI elements
    image_icon1 = PhotoImage(file="Image/send.png")
    window.iconphoto(False, image_icon1)

    Sbackground = PhotoImage(file="Image/sender.png")
    Label(window, image=Sbackground).place(x=-2, y=0)

    Mbackground = PhotoImage(file="Image/id.png")
    Label(window, image=Mbackground, bg='#f4fdfe').place(x=100, y=260)

    host = socket.gethostname()
    Label(window, text=f'ID: {host}', bg='white', fg='black').place(x=140, y=290)

    Button(window, text="+ Select File", width=12, height=1, font='arial 14 bold', bg="#fff", fg="#000", command=select_file).place(x=160, y=150)
    Button(window, text="SEND", width=8, height=1, font='arial 14 bold', bg='#000', fg="#fff", command=sender).place(x=300, y=150)

    window.mainloop()


def Receive():
    main = Toplevel(root)
    main.title("Receive")
    main.geometry('450x560+500+200')
    main.configure(bg="#f4fdfe")
    main.resizable(False, False)

    def receiver():
        ID = SenderID.get()
        filename1 = incoming_file.get()

        def receive_file():
            try:
                s = socket.socket()
                port = 8080
                s.connect((ID, port))

                # Receive the filename
                filename_received = s.recv(1024).decode()
                print(f"Receiving file: {filename_received}")

                # Check if the received filename matches the entered filename
                if filename_received != filename1:
                    status_label.config(
                        text=f"Filename mismatch! Expected '{filename1}', but received '{filename_received}'.",
                        fg="red"
                    )
                    s.close()
                    return

                # Receive the file data and save it with the received filename
                with open(filename_received, 'wb') as file:
                    while (data := s.recv(1024)):
                        file.write(data)

                status_label.config(text="File received successfully!", fg="green")
                print(f"{filename_received} received successfully!")
                s.close()
            except Exception as e:
                status_label.config(text=f"Error: {str(e)}", fg="red")

        threading.Thread(target=receive_file, daemon=True).start()

    # UI elements
    image_icon1 = PhotoImage(file="Image/receive.png")
    main.iconphoto(False, image_icon1)

    Hbackground = PhotoImage(file="Image/receiver.png")
    Label(main, image=Hbackground).place(x=-2, y=0)

    logo = PhotoImage(file="Image/profile.png")
    Label(main, image=logo, bg="#f4fdfe").place(x=100, y=250)

    Label(main, text="Receive", font=('arial', 20), bg="#f4fdfe").place(x=100, y=280)

    Label(main, text="Input Sender ID", font=('arial', 10, 'bold'), bg="#f4fdfe").place(x=20, y=340)
    SenderID = Entry(main, width=25, fg="black", border=2, bg='white', font=('arial', 15))
    SenderID.place(x=20, y=370)
    SenderID.focus()

    Label(main, text="Filename for the incoming file:", font=('arial', 10, 'bold'), bg="#f4fdfe").place(x=20, y=420)
    incoming_file = Entry(main, width=25, fg="black", border=2, bg='white', font=('arial', 15))
    incoming_file.place(x=20, y=450)

    status_label = Label(main, text="", bg="#f4fdfe", fg="black", font=('arial', 10, 'bold'))
    status_label.place(x=20, y=490)

    imageicon = PhotoImage(file="Image/arrow.png")
    rr = Button(main, text="Receive", compound=LEFT, image=imageicon, width=130, bg="#39c790", font="arial 14 bold", command=receiver)
    rr.place(x=20, y=500)

    main.mainloop()


# Main window UI
image_icon = PhotoImage(file="Image/icon.png")
root.iconphoto(False, image_icon)

Label(root, text="File Transfer", font=('Acumin Variable Concept', 20, 'bold'), bg='#f4fdfe').place(x=20, y=30)

Frame(root, width=400, height=2, bg="#f3f5f6").place(x=25, y=80)

send_image = PhotoImage(file="Image/send.png")
send = Button(root, image=send_image, bg="#f4fdfe", bd=0, command=Send)
send.place(x=50, y=100)

receive_image = PhotoImage(file="Image/receive.png")
receive = Button(root, image=receive_image, bg="#f4fdfe", bd=0, command=Receive)
receive.place(x=300, y=100)

Label(root, text="Send", font=('Acumin Variable Concept', 17, 'bold'), bg="#f4fdfe").place(x=65, y=200)
Label(root, text="Receive", font=('Acumin Variable Concept', 17, 'bold'), bg="#f4fdfe").place(x=300, y=200)

background = PhotoImage(file="Image/background.png")
Label(root, image=background).place(x=-2, y=323)

root.mainloop()
